package tp.model;

public class AnimalNotFoundException extends Exception{
}
