/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp.rest;


import tp.model.Animal;

import java.sql.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import javax.swing.JOptionPane;
import tp.model.Cage;
import tp.model.Center;
import tp.model.Position;
/**
 *
 * @author Guettouche
 */
public class MyServiceDAO {
   
    private Connection connection;
    private final static String jdbcUrl = "jdbc:mysql://us-cdbr-iron-east-03.cleardb.net/"
                                       + "ad_6f9e25c6ab73276?user=b201734824b719&password=6dfb9590";
    private final static String username = "b201734824b719";
    private final static String password = "6dfb9590";

    public MyServiceDAO() throws Exception {
//        Connection connection = null;
//
//        Class.forName("com.mysql.jdbc.Driver").newInstance();
//        connection = DriverManager.getConnection(jdbcUrl, username, password);
//        Statement stmt = connection.createStatement();
//        stmt.executeUpdate("USE zoo_manager");
//        stmt.executeUpdate("DROP TABLE IF EXISTS animals");
//        stmt.executeUpdate("DROP TABLE IF EXISTS cages");
//        stmt.executeUpdate("CREATE TABLE animals (id varchar(100), name varchar(100), cage varchar(100), species varchar(100))");
        Connection connection = null;
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/zoo_manager", "root", "");
             System.out.println("connect");
        } catch (SQLException e) {
            System.err.println("SQL Exception thrown while making connection");
        }
    }

    public void addAnimal(Animal animal) throws SQLException {
        Connection connection = this.etablir_la_connexion();
        Statement state = connection.createStatement();
        state.executeUpdate("INSERT INTO animal VALUES('"+animal.getId().toString()+"','"+animal.getName()+"','"+animal.getSpecies()+"',"+this.findCageByName(animal.getCage())+");");
        connection.close();
    }
    
        public void addCage(Cage cage) throws SQLException{
        Connection connection = this.etablir_la_connexion();
        Statement statement01 = connection.createStatement();
        Statement statement02 = connection.createStatement();
        /* Exécution d'une requête de lecture */
        ResultSet resultatset = statement02.executeQuery( "SELECT name FROM cage" );
        boolean bool = false;
        while(resultatset.next()){
            if(cage.getName().equals(resultatset.getString("name"))){
                bool = true;
            }
        }
        if(!bool)
            statement01.executeUpdate("INSERT INTO cage(name, capacity, longitude, latitude, id_center) VALUES('"+cage.getName()+"',"+cage.getCapacity()+",'"+cage.getPosition().getLongitude()+"','"+cage.getPosition().getLatitude()+"',"+1+");");
        else
            JOptionPane.showMessageDialog(null, "Cette cage existe déjà !", "ERROR", 0);
        connection.close();
    } 
        
    
     /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête UPDATE*/
    public void updateAnimalById(Animal animal, String id) throws SQLException{
        Connection connection = this.etablir_la_connexion();
        Statement statement = connection.createStatement();
        statement.executeUpdate( "UPDATE animal SET name = '"+animal.getName()+"' WHERE id = '"+id+"'");
    }
    
    /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête UPDATE*/
    public void updateAll(Animal animal) throws SQLException{
        Connection connection = this.etablir_la_connexion();
        Statement statement = connection.createStatement();
        statement.executeUpdate( "UPDATE animal SET name = '"+animal.getName()+"'" );
    }
    
    /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête DELETE*/
    public void removeAll() throws SQLException{
        Connection connection = this.etablir_la_connexion();
        Statement statement = connection.createStatement();
        statement.executeUpdate( "DELETE * FROM animal" );
    }
    
        /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête DELETE*/
    public void removeAnimalById(String id) throws SQLException{
        Connection connection = this.etablir_la_connexion();     
        Statement statement = connection.createStatement();
        statement.executeUpdate("DELETE FROM animal WHERE id = '"+id+"'");
    }
    
    /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête DELETE*/
    public void removeAnimalByLocation(String location) throws SQLException{
        String identifiant  = this.findCageByName(location);
        Connection connection = this.etablir_la_connexion();
        Statement statement = connection.createStatement();
        statement.executeUpdate( "DELETE FROM animal WHERE id_cage = "+identifiant);
    }
    
    /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête de lecture*/
    public String findCageByName(String cage) throws SQLException{
        Connection connection = this.etablir_la_connexion();
        Statement statement = connection.createStatement();
        ResultSet resultat_set = statement.executeQuery( "SELECT id  FROM cage where name = '"+cage+"';" );
        resultat_set.next();
        int res = resultat_set.getInt("id");
        return res+"";
    }
    
    private Connection etablir_la_connexion() throws SQLException {
        Connection connection = null;
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/zoo_manager", "root", "");
             System.out.println("connect");
        } catch (SQLException e) {
            System.err.println("SQL Exception thrown while making connection");
        }
        return connection;
    }

    /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête de lecture*/
    public Center findCenter() throws SQLException{
        Connection connection = this.etablir_la_connexion();
        Statement statement = connection.createStatement();
        ResultSet resultat = statement.executeQuery( "SELECT id, name, longitude, latitude  FROM center;" );
        Center center = null;
        /* Récupération des données du résultat */
        while ( resultat.next() ) {
            int id = resultat.getInt( "id" );
            String name = resultat.getString( "name" );
            String longitude = resultat.getString( "longitude" );
            String latitude = resultat.getString( "latitude" );
            center = new Center(new LinkedList<>(), new Position(Double.parseDouble(latitude), Double.parseDouble(longitude)), name);
        }
        connection.close();
        return center;
    }
    
    /* Création de l'objet gérant les requêtes ainsi que l'excution d'une requête de lecture*/
    public ArrayList<Cage> findAllCages() throws SQLException{
        ArrayList<Cage> cages = new ArrayList();
        LinkedList animals = new LinkedList();
        Connection connection = this.etablir_la_connexion();
        Statement statement01 = connection.createStatement();
        Statement statement02 = connection.createStatement();
        ResultSet resultat = statement01.executeQuery( "SELECT id, name, capacity, longitude, latitude  FROM cage;" );
        /* Récupération des données du résultat */
        while ( resultat.next() ) {
            int identifiant = resultat.getInt( "id" );
            String name = resultat.getString( "name" );
            int capacity = resultat.getInt( "capacity" );
            String longitude = resultat.getString( "longitude" );
            String latitude = resultat.getString( "latitude" );
            ResultSet resultSet = statement02.executeQuery("SELECT id, name, species FROM animal WHERE id_cage = "+identifiant+";");
            while( resultSet.next() ){
               String id_animal = resultSet.getString("id");
               String name_animal = resultSet.getString("name");
               String species_animal = resultSet.getString("species");
               animals.add(new Animal(name_animal, name ,species_animal, UUID.fromString(id_animal) ));
            }
            Cage cage = new Cage(name,new Position(Double.parseDouble(latitude), Double.parseDouble(longitude)), capacity, animals);
            cages.add(cage);
        }
        connection.close();
        return cages;
    }
    

}
