package tp.rest;

import tp.model.*;

import javax.ws.rs.*;
import javax.xml.bind.JAXBException;
import javax.xml.ws.http.HTTPException;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.UUID;
import javax.ws.rs.core.MediaType;

@Path("/zoo-manager/")
public class MyServiceTP {

    private Center center = new Center(new LinkedList<>(), new Position(49.30494d, 1.2170602d), "Biotropica");

    public MyServiceTP() {
        // Fill our center with some animals
        Cage usa = new Cage(
                "usa",
                new Position(49.305d, 1.2157357d),
                25,
                new LinkedList<>(Arrays.asList(
                        new Animal("Tic", "usa", "Chipmunk", UUID.randomUUID()),
                        new Animal("Tac", "usa", "Chipmunk", UUID.randomUUID())
                ))
        );

        Cage amazon = new Cage(
                "amazon",
                new Position(49.305142d, 1.2154067d),
                15,
                new LinkedList<>(Arrays.asList(
                        new Animal("Canine", "amazon", "Piranha", UUID.randomUUID()),
                        new Animal("Incisive", "amazon", "Piranha", UUID.randomUUID()),
                        new Animal("Molaire", "amazon", "Piranha", UUID.randomUUID()),
                        new Animal("De lait", "amazon", "Piranha", UUID.randomUUID())
                ))
        );

        center.getCages().addAll(Arrays.asList(usa, amazon));
    }

    /**
     * GET method bound to calls on /animals/{something}
     */
    @GET
    @Path("/animals/{id}/")
    @Produces("application/xml")
    public Animal getAnimal(@PathParam("id") String animal_id) throws JAXBException {
        try {
            return center.findAnimalById(UUID.fromString(animal_id));
        } catch (AnimalNotFoundException e) {
            throw new HTTPException(404);
        }
    }

    /**
     * GET method bound to calls on /animals
     */
    @GET
    @Path("/animals/")
    @Produces("application/xml")
    public Center getAnimals(){
        return this.center;
    }

    /**
     * POST method bound to calls on /animals
     */
    @POST
    @Path("/animals/")
    @Consumes({"application/xml", "application/json" })
    public Center postAnimals(Animal animal) throws JAXBException {
        this.center.getCages()
                .stream()
                .filter(cage -> cage.getName().equals(animal.getCage()))
                .findFirst()
                .orElseThrow(() -> new HTTPException(404))
                .getResidents()
                .add(animal);
        return this.center;
    }
    /**
     * pour faire une recherche filtrer à l'aide de critères élaboré {name}
     */
    @GET
    @Path("/find/byName/{name}")
    @Produces("application/xml")
    public Animal findbyName(@PathParam("name") String animal_name) throws JAXBException {
        try {
            return center.animal_Find_Name(animal_name);
        } catch (AnimalNotFoundException e) {
            throw new HTTPException(404);
        }
    }
    
    
    
    /**
     * pour faire une recherche filtrer à l'aide de critères élaboré {latitude},{longitude}
     */
    @GET
    @Path("/find/near/{latitude}/{longitude}/")
    @Produces("application/xml")
    //cette fonction reçoit en entrée deux string qui représente l'altitude et l'ongitude d'un animal donné
    public Cage find_animal_near(@PathParam("latitude")String alt,@PathParam("longitude") String ong) throws JAXBException {
        //on crée la position
        Position P=new Position();
        P.setLatitude(Double.parseDouble(alt));
        P.setLongitude(Double.parseDouble(ong));
        try {
            //on retourne la liste des animaux trouvant Aux alentours de  la position entrée
            return this.center.find_Animal_Near_Position(P);
        } catch (AnimalNotFoundException e) {
            throw new HTTPException(404);
        }
    }
    
    /**
     * pour faire une recherche filtrer à l'aide de critères élaborésa {latitude},{longitude}
     */
    @GET
    @Path("/find/at/{latitude}/{longitude}/")
    @Produces("application/xml")
    //cette fonction reçoit en entrée deux string qui représente l'altitude et l'ongitude d'un animal donné
    public Animal find_animal_at(@PathParam("latitude")String alt,@PathParam("longitude") String ong) throws JAXBException {
        //on crée la position
        Position P=new Position();
        P.setLatitude(Double.parseDouble(alt));
        P.setLongitude(Double.parseDouble(ong));
        try {
            //on retourne l'animal trouvant a la position entrée
            return this.center.find_Animal_By_Position(P);
        } catch (AnimalNotFoundException e) {
            throw new HTTPException(404);
        }
    }
    
    
    /**
     * La suppression de tous les animaux
     */
    @DELETE
    @Path(value="animals")
    public void Remove_all_animals(){
        System.out.println("!!valider la suppression OU annuler la suppression!!");
        System.out.println("rmimez");
        /* La récupération du contenu de toute les cages */
        Collection<Cage> collection_cages = this.center.getCages();
        Iterator<Cage> iterator_cages = collection_cages.iterator();
       /* Parcourir chaque cage */
        while(iterator_cages.hasNext()){
            Cage c = iterator_cages.next();
            /* Effectuer la suppression */
            c.getResidents().removeAll(c.getResidents());
        }

    }
    
    
    /**
     * La suppression d'un animal par rapport a son id
     */
    @DELETE
    @Path(value="animals/remove/{id}")
    public void Remove_an_animal_from_its_id(@PathParam(value="id")String id){
        {
            /* La récupération du contenu de toute les cages */
            Collection<Cage> collection_cages = this.center.getCages();
            Cage c;
            Collection<Animal> collection_animals;
            Iterator<Cage> iterator_cages = collection_cages.iterator();
            Iterator<Animal> iterator_animal;

           /*parcourir la collection des cage afin de trouver lanimal portant l'id entrée*/
            while(iterator_cages.hasNext()){
                c = iterator_cages.next();
                collection_animals = c.getResidents();
                iterator_animal = collection_animals.iterator();
                while(iterator_animal.hasNext()){
                    Animal animal= iterator_animal.next();

                    if(animal.getId().equals(UUID.fromString(id))){
                        /* La supperession de cette animal */
                        collection_animals.remove(animal);
                    }
                }
            }
        }
    }
    
    
        
    /**
     * La suppression d'un animal par rapport a ca ville
     */
    @DELETE
    @Path(value="animals/remove/{ville}")
    public void Remove_an_animal_from_its_city(@PathParam("ville")String ville){
        Collection<Cage> collection_cages = this.center.getCages();
        Iterator<Cage> iterator_cages = collection_cages.iterator();
        /*parcourir la collection des cage afin de trouver lanimal trouvant dans la ville entrée*/
        while(iterator_cages.hasNext()){
            Cage c = iterator_cages.next();
            if(c.getName().equals(ville))
                /* La supperession des animaux trouvant dans la ville entrée en parametre */
                c.getResidents().removeAll(c.getResidents());
        }
    }
    
    
    /**
     * La Modification des information d'un animal par rapport a son id
     */
    @PUT
    @Path(value="animals/")
    @Produces(MediaType.APPLICATION_JSON+";charset=utf-8")
    public void put_animal_by_id(Animal animal_put){
        /* La récupération du contenu de toute les cages */
        Collection<Cage> collection_cages = this.center.getCages();
        Cage c;
        Collection<Animal> collection_animals;
        Iterator<Cage> iterator_cages = collection_cages.iterator();
        Iterator<Animal> iterator_animals;
        /*parcourir la collection des cage afin de trouver lanimal portant l'id entrée*/
        while(iterator_cages.hasNext()){
            c = iterator_cages.next();
            collection_animals = c.getResidents();
            iterator_animals=collection_animals.iterator();
            while(iterator_animals.hasNext()){
                Animal animal= iterator_animals.next();
             	/* Mettre a jour les information de cette animal */
                if(animal.getId().equals(animal_put.getId())){
             	    animal.setCage(animal_put.getCage());
                    animal.setName(animal_put.getName());
                    animal.setSpecies(animal_put.getSpecies());
                }
            }
        }
    }
    
        
    /**
     * La Modification des information des animaux 
     */
    @PUT
    @Path(value="/animals/all")
    public void put_animal(Animal animal){
        /* La récupération du contenu de toute les cages */
        Collection<Cage> collection_cages = this.center.getCages();
        Collection<Animal> collection_animals;
        Iterator<Cage> iterator_cages = collection_cages.iterator();
        Iterator<Animal> iterator_animals;
        /* parcourir la collection des cage */
        while(iterator_cages.hasNext()){
            Cage cage = iterator_cages.next();
            if(cage.getName().equals(animal.getCage())){
                for(Animal a: cage.getResidents()){
                    /* Mettre a jour les information de cette animal */
                    a.setName(animal.getName());

                }
            }
        }

    }
    
}
