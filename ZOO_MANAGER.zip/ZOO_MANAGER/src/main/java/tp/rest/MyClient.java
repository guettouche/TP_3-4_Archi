/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package tp.rest;

import tp.model.Animal;
import tp.model.Cage;
import tp.model.Center;
import tp.model.Position;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.util.JAXBSource;
import javax.xml.namespace.QName;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.handler.MessageContext;
import javax.xml.ws.http.HTTPBinding;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.*;
/**
 *
 * @author Guettouche
 */
public class MyClient {
    private Service service;
    private MyServiceTP my_service;
    private JAXBContext jaxb_context;
    private MyServiceDAO service_dao;
    private static final QName qname = new QName("", "");
    private static final String url = "http://localhost:8084/rest-service/zoo-manager";

    private MyClient() throws Exception {
        try {
            this.service_dao = new MyServiceDAO();
            this.my_service = new MyServiceTP();
            jaxb_context = JAXBContext.newInstance(Center.class, Cage.class, Animal.class, Position.class);
        } catch (JAXBException e) {
            System.out.println("Cannot create JAXBContext " + e);
        }
    }

    private void add_animal(Animal animal) throws JAXBException, SQLException {
        this.service_dao.addAnimal(animal);
        send_request("/animals/", "POST", new JAXBSource(jaxb_context, animal));
    }
    
    
    private void add_cage(Cage cage) throws SQLException{
        this.service_dao.addCage(cage);
    }

        private void get_animals() throws JAXBException {
        send_request("/animals", "GET", null);
    }
  
    private void remove_animals() throws JAXBException, SQLException {
        this.service_dao.removeAll();
        this.my_service.Remove_all_animals();
        send_request("/animals", "DELETE", null);
    }

    private void remove_animals_by_id(String id) throws JAXBException, SQLException {
        this.service_dao.removeAnimalById(id);
        send_request("/animals/" + id, "DELETE", null);
    }

    private void update_all_animals(Animal animal) throws JAXBException, SQLException {
        this.service_dao.updateAll(animal);
        send_request("/animals", "PUT", null);
    }

    
    
        private void update_animals(Animal animal) throws JAXBException, SQLException{
        this.service_dao.updateAll(animal);
        this.my_service.put_animal(animal);
        send_request("/animals", "PUT", new JAXBSource(jaxb_context, animal));
    }
        

    private void update_animal_by_id(Animal animal, String id) throws JAXBException, SQLException {
        this.service_dao.updateAnimalById(animal,id);
        send_request("/animals/" + id, "PUT", new JAXBSource(jaxb_context, animal));
    }

    private void find_by_name(String name) throws JAXBException, UnsupportedEncodingException {
        send_request("/find/byName/" + URLEncoder.encode(name, "UTF-8"), "GET", null);
    }

    private void find_at(Position position) throws Exception {
        send_request("/find/at/", "POST", new JAXBSource(jaxb_context, position));
    }

    private void find_near(Position position) throws Exception {
        send_request("/find/near/", "POST", new JAXBSource(jaxb_context, position));
    }

    private void print_source(Source source) {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();
            Transformer transformer = factory.newTransformer();
            transformer.transform(source, new StreamResult(System.out));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    private void send_request(String Url, String fonction, Source source) {
        try {
            URL main_url = new URL(url + Url);
            HttpURLConnection connect = null;
            connect = (HttpURLConnection) main_url.openConnection();
            connect.setDoOutput(true);
            connect.setRequestMethod(fonction);
            if (source != null) {
                connect.setRequestProperty("Content-Type", "application/xml");
                connect.setRequestProperty("Accept", "application/xml");
                TransformerFactory factory = TransformerFactory.newInstance();
                Transformer transformer = factory.newTransformer();
                OutputStream out_put_stream = connect.getOutputStream();
                transformer.transform(source, new StreamResult(out_put_stream));
                out_put_stream.flush();
            }

            BufferedReader buffered_reader = new BufferedReader(new InputStreamReader((connect.getInputStream())));

            String out;
            while ((out = buffered_reader.readLine()) != null) {
                System.out.println(out);
            }

            connect.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) throws Exception {
        MyClient client = new MyClient();
           // client.senario();
          //  client.add_cage(new Cage("Rouen", new Position(49.443889,1.103333), 1000));
           client.add_animal(new Animal("BENZI", "Rouen", "Arapaima-gigas", UUID.randomUUID()));
          //  client.remove_animals();
          //  client.update_animals(new Animal("Guettouche","Rouen","Arapaima-gigas",UUID.randomUUID()));
           // client.remove_animals_by_id("7267fa5c-fe92-4c9d-9b1a-2e8ab509b218");
          //client.update_animal_by_id(new Animal("Alice", "amazon", "Arapaima-gigas", UUID.randomUUID()), UUID.randomUUID().toString());
          //client.find_by_name("Tic");
          //client.find_at(new Position(49.305,1.2157357));
          //client.find_near(new Position(49.305,1.2157357));
          //client.senario();
    }

    public void senario() throws Exception {
        MyClient client = new MyClient();
        client.get_animals();
        print(" ");
        client.remove_animals();
        print(" ");
        client.get_animals();
        print(" ");

        client.add_cage(new Cage("Rouen", new Position(49.443889,1.103333), 1000));
        print(" ");
        client.add_animal(new Animal("Panda", "Rouen", "Panda"));
        print(" ");

        client.add_cage(new Cage("Paris", new Position(48.856578, 2.351828), 1000));
        client.add_animal(new Animal("Hocco unicorne", "Paris", "Hocco unicorne"));

        client.get_animals();
        print(" ");

        client.add_cage(new Cage("Paris", new Position(48.856578, 2.351828), 1000));
        client.add_animal(new Animal("Hocco unicorne", "Paris", "Hocco unicorne"));

        client.update_animals(new Animal("Lagotriche", "Rouen", "Lagotriche"));

        client.get_animals();
        print(" ");

        client.add_cage(new Cage("Somalie", new Position(2.333333, 48.85), 1000));
        client.add_animal(new Animal("Océanite de Matsudaira", "Somalie", "Océanite de Matsudaira"));

        client.add_animal(new Animal("Ara de Spix", "Rouen", "Ara de Spix"));

        client.add_cage(new Cage("Bihorel", new Position(49.455278, 1.116944), 1000));
        client.add_animal(new Animal("Galago de Rondo", "Bihorel", "Galago de Rondo"));

        client.add_cage(new Cage("Londre", new Position( 51.504872, -0.07857), 1000));
        client.add_animal(new Animal("Palette des Sulu", "Londre", "Palette des Sulu"));

        client.add_animal(new Animal("Kouprey", "Paris", "Kouprey"));

        client.add_animal(new Animal("Tuit tuit", "Paris", "Tuit tuit"));

        client.add_cage(new Cage("Canada", new Position( 43.2, -80.38333), 1000));
        client.add_animal(new Animal("Saiga", "Canada", "Saiga"));

        client.add_cage(new Cage("Porto Vecchio", new Position( 41.5895241, 9.2627), 1000));
        client.add_animal(new Animal("Inca de Bonaparte", "Porto Vecchio", "Inca de Bonaparte"));

        client.get_animals();
        print(" ");

        client.add_cage(new Cage("Montreux", new Position( 46.4307133,  6.9113575), 1000));
        client.add_animal(new Animal("Râle de Zapata", "Montreux", "Râle de Zapata"));

        client.add_cage(new Cage("Villers Bocage", new Position( 50.0218, 2.3261), 1000));
        client.add_animal(new Animal("Rhinocéros de Java", "Villers Bocage", "Rhinocéros de Java"));

        client.add_cage(new Cage("usa", new Position( 49.305d, 1.2157357d), 1000));
        for (int i = 0; i < 101; ++i) {
            client.add_animal(new Animal("Dalmatien"+i, "usa", "Dalmatien"));
        }

        client.get_animals();
        print(" ");
        client.remove_animals();
        client.get_animals();
        print(" ");

        //client.find_by_name("Galago de Rondo");
        client.remove_animals();
        client.remove_animals();

        client.get_animals();
        print(" ");
        client.find_near(new Position(49.443889,1.103333));
        client.find_at(new Position(49.443889,1.103333));


        client.get_animals();
        print(" ");
    }

    private void print(String message) {
        System.out.println(message);
    }
    
   
    
}
